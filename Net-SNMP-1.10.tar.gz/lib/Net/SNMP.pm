# -*- mode: perl -*-
# ============================================================================

package Net::SNMP;

# $Id: SNMP.pm,v 1.1 1998/10/14 12:28:33 dtown Exp $
# $Source: /home/dtown/Projects/Net-SNMP/SNMP.pm,v $

# The module Net::SNMP implements an object oriented interface to the Simple 
# Network Management Protocol version-1. The module allows a Perl application
# to retrieve or update information on a remote host using the SNMP protocol.

# Copyright (c) 1998 David M. Town <town+@pitt.edu>.
# All rights reserved.

# This program is free software; you may redistribute it and/or modify it
# under the same terms as Perl itself. 

# ============================================================================

## Version of Net::SNMP module

$Net::SNMP::VERSION = 1.10;

## Required version of Perl

require 5.003;

## Handle exporting of symbols

use Exporter();

use vars qw(@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS);

@ISA         = qw(Exporter);
@EXPORT      = qw(INTEGER OCTET_STRING NULL OBJECT_IDENTIFIER
                  IPADDRESS COUNTER GAUGE TIMETICKS OPAQUE
               );
@EXPORT_OK   = qw(COLD_START WARM_START LINK_DOWN LINK_UP 
                  AUTHENTICATION_FAILURE EGP_NEIGHBOR_LOSS
                  ENTERPRISE_SPECIFIC
               );
%EXPORT_TAGS = (asn1        => [@EXPORT],
                generictrap => [@EXPORT_OK], 
                ALL         => [@EXPORT, @EXPORT_OK]
               );

## Import socket() defines and structure manipulators

use Socket qw(PF_INET SOCK_DGRAM inet_aton inet_ntoa sockaddr_in);

sub IPPROTO_UDP         {   17 }

## ASN.1 Basic Encoding Rules type definitions

sub INTEGER             { 0x02 }  # INTEGER      
sub OCTET_STRING        { 0x04 }  # OCTET STRING
sub NULL                { 0x05 }  # NULL       
sub OBJECT_IDENTIFIER   { 0x06 }  # OBJECT IDENTIFIER
sub SEQUENCE            { 0x30 }  # SEQUENCE       

sub IPADDRESS           { 0x40 }  # IpAddress     
sub COUNTER             { 0x41 }  # Counter      
sub GAUGE               { 0x42 }  # Gauge       
sub TIMETICKS           { 0x43 }  # TimeTicks  
sub OPAQUE              { 0x44 }  # Opaque    

sub GET_REQUEST         { 0xa0 }  # GetRequest-PDU    
sub GET_NEXT_REQUEST    { 0xa1 }  # GetNextRequest-PDU 
sub GET_RESPONSE        { 0xa2 }  # GetResponse-PDU
sub SET_REQUEST         { 0xa3 }  # SetRequest-PDU
sub TRAP                { 0xa4 }  # Trap-PDU

## RFC 1157 SNMP version-1

sub SNMP_VERSION_1      { 0x00 }  # RFC 1157 SNMP version-1
sub SNMP_UDP_PORT       {  161 }  # RFC 1157 standard UDP port for SNMP

## RFC 1157 generic-trap definitions

sub COLD_START             { 0 }  # coldStart(0)
sub WARM_START             { 1 }  # warmStart(1)
sub LINK_DOWN              { 2 }  # linkDown(2)
sub LINK_UP                { 3 }  # linkUp(3)
sub AUTHENTICATION_FAILURE { 4 }  # authenticationFailure(4)
sub EGP_NEIGHBOR_LOSS      { 5 }  # egpNeighborLoss(5)
sub ENTERPRISE_SPECIFIC    { 6 }  # enterpriseSpecific(6)

## Default, minimum, and maximum values 

sub DEFAULT_HOSTNAME    { 'localhost' }
sub DEFAULT_COMMUNITY   {    'public' }

sub DEFAULT_MTU         {   484 } # RFC 1157 maximum size in octets
sub DEFAULT_TIMEOUT	{   2.0 } # Timeout period for UDP in seconds
sub DEFAULT_RETRIES	{     5 } # Number of retransmissions 

sub MINIMUM_MTU         {    30 }    
sub MINIMUM_TIMEOUT     {   1.0 }   
sub MINIMUM_RETRIES     {     0 }     

sub MAXIMUM_MTU         { 65535 }
sub MAXIMUM_TIMEOUT     {  60.0 }   
sub MAXIMUM_RETRIES     {    20 }

## Unique filehandle index for each SNMP session opened

my $SOCKET_INDEX = 0;


# [public methods] -----------------------------------------------------------

sub session
{
   my ($class, %argv) = @_;
   my ($port, $host_addr, $proto) = (SNMP_UDP_PORT, undef, undef);
   
   # Create a new data structure for the object
   my $this = bless {
        'hostname'       => DEFAULT_HOSTNAME,
        'sockaddr_in'    => undef,
        'socket'         => undef,
        'community'      => DEFAULT_COMMUNITY,
        'request_id'     => (int(rand 0xff) + 1),
        'error_status'   => 0,
        'var_bind_list'  => undef,
        'timeout'        => DEFAULT_TIMEOUT,
        'retries'        => DEFAULT_RETRIES,
        'mtu'            => DEFAULT_MTU,
	'error'          => undef,
        'debug'          => 0x0,
        'translate'      => 0x1,
        'buffer'         => '',
   }, $class;

   # Validate the passed arguments 
   foreach (keys %argv) {
      if (/^-?hostname$/i) {
         if ($argv{$_} eq '') {
            $this->{'error'} = 'Empty hostname specified';
         } else { 
            $this->{'hostname'} = $argv{$_}; 
         }
      } elsif (/^-?community$/i) {
         if ($argv{$_} eq '') {
            $this->{'error'} = 'Empty community specified';
         } else { 
            $this->{'community'} = $argv{$_}; 
         }
      } elsif (/^-?port$/i) {
         if ($argv{$_} !~ /^\d+$/) {
            $this->{'error'} = 'Expected numeric port number'; 
         } else { 
            $port = $argv{$_}; 
         }
      } else {
         $this->{'error'} = sprintf("Invalid argument '%s'", $_);  
      }
      if (defined($this->{'error'})) {
         if (wantarray) {
            return (undef, $this->{'error'});
         } else {
            return undef;
         }
      }
   }    
  
   # Generate a typeglob reference for the socket
   $this->{'socket'} = \*{sprintf("Net::SNMP::SOCKET%03d", $SOCKET_INDEX++)}; 

   # Resolve the hostname to an IP address
   if (!defined($host_addr = inet_aton($this->{'hostname'}))) {
      $this->{'error'} = sprintf("Unable to resolve hostname '%s'", 
                            $this->{'hostname'}
                         );
      if (wantarray) {
         return (undef, $this->{'error'});
      } else {
         return undef;
      }
   }

   # Pack the address and port information
   $this->{'sockaddr_in'} = sockaddr_in($port, $host_addr);

   # Get the protocol number for UDP
   if (!defined($proto = scalar(getprotobyname('udp')))) { 
      $proto = IPPROTO_UDP;
   } 

   # Open an UDP socket for the object
   if (!socket($this->{'socket'}, PF_INET, SOCK_DGRAM, $proto)) {
      $this->{'error'} = sprintf("socket(): %s", $!);
      if (wantarray) {
         return (undef, $this->{'error'});
      } else {
         return undef;
      }
   }

   # Return the object and empty error message (in list context) 
   if (wantarray) {
      return ($this, '');
   } else {
      return $this;
   }
}

sub close
{
   my ($this) = @_;
   
   # Clear all of the buffers and errors
   $this->_object_ClearBuffer;
   $this->_object_ClearVarBindList;
   $this->_object_ClearError;

   # Close the UDP socket and clear the variable name so that
   # we can tell that the socket has been closed elsewhere.

   if (defined($this->{'socket'})) { close($this->{'socket'}); }
   $this->{'socket'} = undef;
}

sub get_request
{
   my ($this, @oids) = @_;

   if (!defined($this->_snmp_EncodeGetRequest(@oids))) { 
      return $this->_object_EncodeError; 
   }

   if (!defined($this->_udp_SendMessage)) { 
      return $this->_object_DecodeError; 
   }
  
   $this->_snmp_DecodeGetResponse;
}

sub get_next_request
{
   my ($this, @oids) = @_;

   if (!defined($this->_snmp_EncodeGetNextRequest(@oids))) {
      return $this->_object_EncodeError;
   }

   if (!defined($this->_udp_SendMessage)) {
      return $this->_object_DecodeError;
   }

   $this->_snmp_DecodeGetResponse;
}

sub set_request
{
   my ($this, @pairs) = @_;

   if (!defined($this->_snmp_EncodeSetRequest(@pairs))) {
      return $this->_object_EncodeError;
   }

   if (!defined($this->_udp_SendMessage)) {
      return $this->_object_DecodeError;
   }

   $this->_snmp_DecodeGetResponse;
}

sub trap
{
   my ($this, %argv) = @_;

   # Use Sys:Hostname to determine the IP address of the client sending
   # the trap.  Only require the module for Trap-PDUs.

   use Sys::Hostname;

   # Setup default values for the Trap-PDU by creating new entries in 
   # the Net::SNMP object.

   # Use iso.org.dod.internet.private.enterprises for the default enterprise. 
   $this->{'enterprise'} = '1.3.6.1.4.1';  

   # Get the address of the client sending the trap. 
   $this->{'agent_addr'} = inet_ntoa(scalar(gethostbyname(hostname())));

   # Use enterpriseSpecific(6) for the generic-trap type.
   $this->{'generic_trap'} = ENTERPRISE_SPECIFIC;

   # Set the specific-trap type to 0.
   $this->{'specific_trap'} = 0;

   # Use the "uptime" of the script for the time-stamp.
   $this->{'time_stamp'} = ((time() - $^T) * 100);

   # Create a local copy of the VarBindList.
   my @var_bind_list = ();


   # Validate the passed arguments
   foreach (keys %argv) {
      if (/^-?enterprise$/i) {
         if ($argv{$_} !~ /^\.?\d+\.\d+(\.\d+)*/) {
            return $this->_snmp_EncodeError("Expected enterprise as OBJECT " .
                             "IDENTIFIER in dotted notation" 
                          );
         } else {
            $this->{'enterprise'} = $argv{$_};
         }
      } elsif (/^-?agentaddr$/i) {
         if ($argv{$_} !~ /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/) {
            return $this->_snmp_EncodeError("Expected agent-addr in dotted ".
                             "notation"
                          );
         } else {
            $this->{'agent_addr'} = $argv{$_};
         }
      } elsif (/^-?generictrap$/i) {
         if ($argv{$_} !~ /^\d+$/) {
            return $this->_snmp_EncodeError("Expected numeric generic-trap " .
                             "type"
                          );
         } else {
            $this->{'generic_trap'} = $argv{$_};
         }
      } elsif (/^-?specifictrap$/i) {
         if ($argv{$_} !~ /^\d+$/) {
            return $this->_snmp_EncodeError("Expected numeric specific-trap " .
                             "type"
                          );
         } else {
            $this->{'specific_trap'} = $argv{$_};
         }
      } elsif (/^-?timestamp$/i) {
         if ($argv{$_} !~ /^\d+$/) {
            return $this->_snmp_EncodeError("Expected numeric time-stamp");
         } else {
            $this->{'time_stamp'} = $argv{$_};
         }
      } elsif (/^-?varbindlist$/i) {
         if (ref($argv{$_}) ne 'ARRAY') {
            return $this->_snmp_EncodeError("Expected array reference for " .
                             "variable-bindings"
                          );
         } else {
            @var_bind_list = @{$argv{$_}}; 
         }   
      } else {
         return $this->_snmp_EncodeError("Invalid argument '%s'", $_);
      }
   }

   if (!defined($this->_snmp_EncodeTrap(@var_bind_list))) {
      return $this->_object_EncodeError;
   }

   $this->_udp_SendBuffer;
}

sub get_table
{
   my ($this, $base_oid) = @_;
   my ($repeat_cnt, $table, $result, $next_oid) = (0, undef, undef, undef);

   $next_oid = $base_oid;

   # Use get-next-requests until the response is not a subtree of the
   # base OBJECT IDENTIFIER.  Return the table only if there are no
   # errors other than a noSuchName(2) error since the table could
   # be at the end of the tree.

   do {
      if (defined($result)) {
         if (!defined($table->{$next_oid})) {
            $table->{$next_oid} = $result->{$next_oid};
         } else {
            $repeat_cnt++;
         }
      }
      # Check to make sure that the remote host does not respond
      # incorrectly causing the get-next-requests to loop forever.
      if ($repeat_cnt > 5) {
         return $this->_object_DecodeError(
                          "Loop detected with table on remote host"
                       );
      }
      if (!defined($this->_snmp_EncodeGetNextRequest($next_oid))) {
         return $this->_object_EncodeError;
      }
      if (!defined($this->_udp_SendMessage)) {
         return $this->_object_DecodeError;
      }
      if (!defined($result = $this->_snmp_DecodeGetResponse)) {
         # Check for noSuchName(2) error
         if ($this->{'error_status'} == 2) {
            return ($this->{'var_bind_list'} = $table);
         } else {
            return $this->_object_DecodeError;
         }
      }
      ($next_oid) = keys(%{$result});
   } while (_asn1_oid_subtree($base_oid, $next_oid));

   if (!defined($table)) {
      $this->_object_DecodeError("Requested table is empty");
   }

   $this->{'var_bind_list'} = $table;
}

sub error
{
   my ($this) = @_;

   if (!defined($this->{'error'})) { return ''; }
  
   $this->{'error'};
}

sub error_status  { $_[0]->{'error_status'};  }

sub var_bind_list { $_[0]->{'var_bind_list'}; }

sub timeout
{
   my ($this, $timeout) = @_;

   # Clear any previous error message
   $this->_object_ClearError;

   if (defined($timeout)) {
      if (($timeout >= MINIMUM_TIMEOUT) && ($timeout <= MAXIMUM_TIMEOUT)) { 
         $this->{'timeout'} = $timeout; 
      } else {
         return $this->_object_EncodeError("Timeout out of range [%03.01f " .
                          "- %03.01f seconds]", MINIMUM_TIMEOUT, MAXIMUM_TIMEOUT
                       );
      } 
   }

   $this->{'timeout'};
}

sub retries 
{
   my ($this, $retries) = @_;

   # Clear any previous error message
   $this->_object_ClearError;

   if (defined($retries)) {
      if (($retries >= MINIMUM_RETRIES) && ($retries <= MAXIMUM_RETRIES)) { 
         $this->{'retries'} = $retries; 
      } else {
         return $this->_object_EncodeError("Retries out of range [%d - %d]",
                          MINIMUM_RETRIES, MAXIMUM_RETRIES
                       );
      }
   }

   $this->{'retries'};
}

sub mtu 
{
   my ($this, $mtu) = @_;

   # Clear any previous error message
   $this->_object_ClearError;

   if (defined($mtu)) {
      if (($mtu >= MINIMUM_MTU) && ($mtu <= MAXIMUM_MTU )) { 
         $this->{'mtu'} = $mtu; 
      } else {
         return $this->_object_EncodeError("MTU out of range [%d - %d octets]",
                          MINIMUM_MTU, MAXIMUM_MTU
                       );
      }
   }

   $this->{'mtu'};
}

sub translate
{
   my ($this) = @_;

   if ($this->{'translate'}) {
      $this->{'translate'} = 0x0;
   } else {
      $this->{'translate'} = 0x1;
   }
}

sub debug
{
   my ($this) = @_;

   if ($this->{'debug'}) {
      $this->{'debug'} = 0x0;
   } else {
      $this->{'debug'} = 0x1;
   }
}

sub DESTROY { $_[0]->close; }

# [private methods] ----------------------------------------------------------


###
## RFC 1157 Simple Network Managment Protocol (SNMP) encode methods
###

sub _snmp_EncodeGetRequest
{
   my ($this, @oids) = @_;

   # Clear any previous error message
   $this->_object_ClearError;

   $this->_snmp_EncodeMessage(GET_REQUEST, 
             $this->_snmp_CreateOidNullPairs(@oids)
          ); 
}

sub _snmp_EncodeGetNextRequest
{
   my ($this, @oids) = @_;

   # Clear any previous error message
   $this->_object_ClearError;

   $this->_snmp_EncodeMessage(GET_NEXT_REQUEST,
             $this->_snmp_CreateOidNullPairs(@oids)
          );
}

sub _snmp_EncodeGetResponse
{
   my ($this) = @_;

   # Clear any previous error message
   $this->_object_ClearError;

   $this->_snmp_EncodeError("GetResponse-PDU not supported");
}


sub _snmp_EncodeSetRequest
{
   my ($this, @oid_values) = @_;

   # Clear any previous error message
   $this->_object_ClearError;

   $this->_snmp_EncodeMessage(SET_REQUEST,
             $this->_snmp_CreateOidValuePairs(@oid_values)
          );
}

sub _snmp_EncodeTrap
{
   my ($this, @oid_values) = @_;

   # Clear any previous error message
   $this->_object_ClearError;

   $this->_snmp_EncodeMessage(TRAP,
             $this->_snmp_CreateOidValuePairs(@oid_values)
          );
}

sub _snmp_EncodeMessage
{
   my ($this, $type, @var_bind) = @_;

   # Do not do anything if there has already been an error
   if (defined($this->{'error'})) { return $this->_snmp_EncodeError; }

   if (!defined($type)) { 
      return $this->_snmp_EncodeError("No SNMP PDU type defined");
   }

   # We need to encode the message in reverse order so eveything ends
   # up in the correct place.  First check to see if the the passed
   # message type is supported.

   if (($type != GET_REQUEST) && ($type != GET_NEXT_REQUEST) && 
         ($type != SET_REQUEST) && ($type != TRAP)) {
      return $this->_snmp_EncodeError("PDU type [0x%02x] not supported", $type);
   } 

   # We need to reset the buffer that might have been defined 
   # from a previous message and clear the var_bind_list. 
   $this->_object_ClearBuffer;
   $this->_object_ClearVarBindList;
  
   # Encode the PDU or Trap-PDU
   if ($type == TRAP) { 
      if (!defined($this->_snmp_EncodeTrapPDU(@var_bind))) {
         return $this->_snmp_EncodeError;
      }
   } else {
      if (!defined($this->_snmp_EncodePDU(@var_bind))) {
         return $this->_snmp_EncodeError;
      }
   }

   # Encode the PDU type
   if (!defined($this->_asn1_Encode($type))) { 
      return $this->_snmp_EncodeError; 
   }

   # Encode the community name
   if (!defined($this->_asn1_Encode(OCTET_STRING, $this->{'community'}))) {
      return $this->_snmp_EncodeError;
   }

   # Encode the SNMP version
   if (!defined($this->_asn1_Encode(INTEGER, SNMP_VERSION_1))) {
      return $this->_snmp_EncodeError;
   } 

   # Encode the SNMP message SEQUENCE 
   if (!defined($this->_asn1_Encode(SEQUENCE))) {
      return $this->_snmp_EncodeError;
   } 

   # Return the buffer
   $this->{'buffer'};
}
 
sub _snmp_EncodePDU
{
   my ($this, @var_bind) = @_;

   # We need to encode eveything in reverse order so the 
   # objects end up in the correct place.

   # Encode the variable-bindings 
   if (!defined($this->_snmp_EncodeVarBindList(@var_bind))) {
      return $this->_snmp_EncodeError;
   } 

   # Encode the error-index as 0
   if (!defined($this->_asn1_Encode(INTEGER, 0))) {
      return $this->_snmp_EncodeError;
   } 
   
   # Encode the error-status as noError(0)
   if (!defined($this->_asn1_Encode(INTEGER, 0))) {
      return $this->_snmp_EncodeError;
   }

   # Encode the request-id, after incrementing by one
   if (!defined($this->_asn1_Encode(INTEGER, ++$this->{'request_id'}))) {
      return $this->_snmp_EncodeError;
   }
 
   # Return the buffer 
   $this->{'buffer'}; 
}

sub _snmp_EncodeTrapPDU
{
   my ($this, @var_bind) = @_;

   # We need to encode eveything in reverse order so the
   # objects end up in the correct place.

   # Encode the variable-bindings
   if (!defined($this->_snmp_EncodeVarBindList(@var_bind))) {
      return $this->_snmp_EncodeError;
   }

   # Encode the time-stamp
   if (!defined($this->_asn1_Encode(TIMETICKS, $this->{'time_stamp'}))) {
      return $this->_snmp_EncodeError;
   }

   # Encode the specific-trap type
   if (!defined($this->_asn1_Encode(INTEGER, $this->{'specific_trap'}))) {
      return $this->_snmp_EncodeError;
   }

   # Encode the generic-trap type
   if (!defined($this->_asn1_Encode(INTEGER, $this->{'generic_trap'}))) {
      return $this->_snmp_EncodeError;
   }

   # Encode the agent-addr
   if (!defined($this->_asn1_Encode(IPADDRESS, $this->{'agent_addr'}))) {
      return $this->_snmp_EncodeError;
   }

   # Encode the enterprise
   if (!defined(
         $this->_asn1_Encode(OBJECT_IDENTIFIER, $this->{'enterprise'}))
      ) { 
      return $this->_snmp_EncodeError;
   }

   # Return the buffer
   $this->{'buffer'};
}

sub _snmp_EncodeVarBindList
{
   my ($this, @var_bind) = @_;
   my ($type, $value) = (undef, '');

   # The passed array is expected to consist of groups of four values
   # consisting of two sets of ASN.1 types and their values.

   if ((scalar(@var_bind) % 4)) {
      return $this->_snmp_EncodeError("Invalid number of VarBind parameters " .
                       "[%d]", scalar(@var_bind) 
                    );
   }
 
   # Encode the objects from the end of the list, so they are wrapped 
   # into the packet as expected.  Also, check to make sure that the 
   # OBJECT IDENTIFIER is in the correct place.

   while (@var_bind) {
      # Encode the ObjectSyntax
      $value = pop(@var_bind);
      $type  = pop(@var_bind);
      if (!defined($this->_asn1_Encode($type, $value))) { 
         return $this->_snmp_EncodeError; 
      }
      # Encode the ObjectName 
      $value = pop(@var_bind);
      $type  = pop(@var_bind);
      if ($type != OBJECT_IDENTIFIER) {
         return $this->_snmp_EncodeError(
                          "Expected OBJECT IDENTIFIER in VarBindList"
                       );
      }
      if (!defined($this->_asn1_Encode($type, $value))) {
         return $this->_snmp_EncodeError;
      }
      # Encode the VarBind SEQUENCE 
      if (!defined($this->_asn1_Encode(SEQUENCE))) {
         return $this->_snmp_EncodeError;
      } 
   } 

   # Encode the VarBindList SEQUENCE 
   if (!defined($this->_asn1_Encode(SEQUENCE))) { 
      return $this->_snmp_EncodeError; 
   }

   # Return the buffer
   $this->{'buffer'};
}

sub _snmp_CreateOidNullPairs
{
   my ($this, @oids) = @_;
   my ($oid) = (undef);
   my (@pairs) = ();

   while (@oids) {
      $oid = shift(@oids);
      if ($oid !~ /^\.?\d+\.\d+(\.\d+)*/) {
         return $this->_snmp_EncodeError("Expected OBJECT IDENTIFIER in " .
                          "dotted notation"
                       );
      }
      push(@pairs, OBJECT_IDENTIFIER, $oid, NULL, '');
   }

   @pairs;
}

sub _snmp_CreateOidValuePairs
{
   my ($this, @oid_values) = @_;
   my ($oid) = (undef);
   my (@pairs) = ();

   if ((scalar(@oid_values) % 3)) {
      return $this->_snmp_EncodeError("Expected [OBJECT IDENTIFIER, ASN.1 " .
                       "type, object value] combination"
                    );
   }

   while (@oid_values) {
      $oid = shift(@oid_values);
      if ($oid !~ /^\.?\d+\.\d+(\.\d+)*/) {
         return $this->_snmp_EncodeError("Expected OBJECT IDENTIFIER in " .
                          "dotted notation"
                       );
      }
      push(@pairs, OBJECT_IDENTIFIER, $oid);
      push(@pairs, shift(@oid_values), shift(@oid_values));
   }

   @pairs;
}

sub _snmp_EncodeError
{
   my ($this, @error) = @_;

   # Clear the buffer
   $this->_object_ClearBuffer;

   $this->_object_Error(@error);
}


###
## RFC 1157 Simple Network Managment Protocol (SNMP) decode methods
###

sub _snmp_DecodeGetRequest
{
   my ($this) = @_;

   $this->_snmp_DecodeMessage(GET_REQUEST);
}

sub _snmp_DecodeGetNextRequest
{
   my ($this) = @_;

   $this->_snmp_DecodeMessage(GET_NEXT_REQUEST);
}

sub _snmp_DecodeGetResponse
{
   my ($this) = @_;

   $this->_snmp_DecodeMessage(GET_RESPONSE);
}

sub _snmp_DecodeSetRequest
{
   my ($this) = @_;

   $this->_snmp_DecodeMessage(SET_REQUEST);
}

sub _snmp_DecodeTrap
{
   my ($this) = @_;

   $this->_snmp_DecodeError("Trap-PDU not supported");
}

sub _snmp_DecodeMessage
{
   my ($this, $type) = @_;
   my ($value) = (undef);

   # First we need to reset the var_bind_list and errors that
   # might have been set from a previous message.

   $this->_object_ClearVarBindList;
   $this->_object_ClearError;

   if (!defined($type)) {
      return $this->_snmp_DecodeError("SNMP PDU type not defined");
   }
   if (($type != GET_REQUEST) && ($type != GET_NEXT_REQUEST) &&
         ($type != GET_RESPONSE) &&($type != SET_REQUEST)) {
      return $this->_snmp_DecodeError("PDU type [0x%02x] not supported", $type);
   }

   # Decode the message SEQUENCE
   if (!defined($value = $this->_asn1_Decode(SEQUENCE))) {
      return $this->_snmp_DecodeError;
   } 
   if ($value != $this->_object_BufferLength) {
      return $this->_snmp_DecodeError("Encoded message length not equal to " .
                       "remaining data length"
                    );
   }

   # Decode the version
   if (!defined($value = $this->_asn1_Decode(INTEGER))) {
      return $this->_snmp_DecodeError;
   } 
   if ($value != SNMP_VERSION_1) {
      return $this->_snmp_DecodeError("Unsupported SNMP version [0x%02x]", 
                       $value
                    );
   }

   # Decode the community
   if (!defined($value = $this->_asn1_Decode(OCTET_STRING))) {
      return $this->_snmp_DecodeError;
   }
   if ($value ne $this->{'community'}) {
      return $this->_snmp_DecodeError("Received community [%s] is not equal " .
                       "to transmitted community [%s]", $value, 
                          $this->{'community'}
                    );
   } 

   # Decode the PDU type
   if (!defined($value = $this->_asn1_Decode($type))) {
      return $this->_snmp_DecodeError;
   }

   # Decode the PDU
   $this->_snmp_DecodePDU;
}

sub _snmp_DecodePDU
{
   my ($this) = @_;
   my ($value, $status) = (undef, undef);

   my @error_status = qw(
	 noError 
	 tooBig 
	 noSuchName 
	 badValue
	 readOnly
	 genError
      );

   # Decode the request-id
   if (!defined($value = $this->_asn1_Decode(INTEGER))) {
      return $this->_snmp_DecodeError;
   }
   if ($value != $this->{'request_id'}) {
      return $this->_snmp_DecodeError("Received request-id [%s] is not equal " .
                       "to transmitted request-id [%s]", $value,
                          $this->{'request_id'}
                    );
   }   

   # Decode the error-status and error-index
   if (!defined($status = $this->_asn1_Decode(INTEGER))) {
      return $this->_snmp_DecodeError;
   }
   if (!defined($value = $this->_asn1_Decode(INTEGER))) {
      return $this->_snmp_DecodeError;
   }
   if ($status != 0) {
      $this->{'error_status'} = $status;
      return $this->_snmp_DecodeError("Received SNMP %s(%s) error-status at " .
                       "error-index %s", $error_status[$status], $status,
                          $value
                    );
   } 

   # Decode the VarBindList
   $this->_snmp_DecodeVarBindList;
}

sub _snmp_DecodeVarBindList
{
   my ($this) = @_;
   my ($value, $oid) = (undef, undef);

   # Decode the VarBindList SEQUENCE
   if (!defined($value = $this->_asn1_Decode(SEQUENCE))) {
      return $this->_snmp_DecodeError;
   }
   if ($value != $this->_object_BufferLength) {
      return $this->_snmp_DecodeError("Encoded VarBindList length not equal " .
                       " to remaining data length"
                    );
   }

   while ($this->_object_BufferLength) {
      # Decode the VarBind SEQUENCE
      if (!defined($value = $this->_asn1_Decode(SEQUENCE))) {
         return $this->_snmp_DecodeError;
      }
      # Decode the ObjectName
      if (!defined($oid = $this->_asn1_Decode(OBJECT_IDENTIFIER))) {
         return $this->_snmp_DecodeError;
      }
      # Decode the ObjectSyntax
      if (!defined($value = $this->_asn1_Decode)) {
         return $this->_snmp_DecodeError;
      }
      # Create a hash consisting of the OBJECT IDENTIFIER as a
      # key and the ObjectSyntax as the value.
      $this->_debug_Message("{ %s => %s }\n", $oid, $value);
      $this->{'var_bind_list'}->{$oid} = $value;
   }

   # Return the var_bind_list hash
   $this->{'var_bind_list'};
}

sub _snmp_DecodeError
{
   my ($this, @error) = @_;

   # Clear var_bind_list
   $this->_object_ClearVarBindList;

   $this->_object_Error(@error);
}


###
## Abstract Syntax Notation One (ASN.1) encode methods
### 

sub _asn1_Encode
{ 
   my ($this, $type, $value) = @_;
   my ($method) = (undef);

   my $encode = {
        INTEGER,            '_asn1_EncodeInteger',
        OCTET_STRING,       '_asn1_EncodeOctetString',
        NULL,               '_asn1_EncodeNull',
        OBJECT_IDENTIFIER,  '_asn1_EncodeObjectIdentifier',
        SEQUENCE,           '_asn1_EncodeSequence',
        IPADDRESS,          '_asn1_EncodeIpAddress',
        COUNTER,            '_asn1_EncodeCounter',
        GAUGE,              '_asn1_EncodeGauge',
        TIMETICKS,          '_asn1_EncodeTimeTicks',
        OPAQUE,             '_asn1_EncodeOpaque',
        GET_REQUEST,        '_asn1_EncodeGetRequest',
        GET_NEXT_REQUEST,   '_asn1_EncodeGetNextRequest',
        GET_RESPONSE,       '_asn1_EncodeGetResponse',
        SET_REQUEST,        '_asn1_EncodeSetRequest',
        TRAP,               '_asn1_EncodeTrap',
   };

   if (!defined($type)) {
      return $this->_asn1_EncodeError("ASN.1 type not defined");
   }

   if (defined($method = $encode->{$type})) {
      $this->$method($value);
   } else {
      $this->_asn1_EncodeError("Unknown ASN.1 type [%s]", $type);
   }
}

sub _asn1_EncodeTypeLength
{
   my ($this, $type, $value) = @_;
   my ($length) = (0);

   if (defined($this->{'error'})) { return $this->_asn1_EncodeError; }

   if (!defined($type)) {
      return $this->_asn1_Error("ASN.1 type not defined");
   }

   if (!defined($value)) { $value = ''; }

   $length = length($value);

   if ($length < 0x80) {
      return $this->_object_PutBuffer(
                       join('', pack('C2', $type, $length), $value)
                    );
   } elsif ($length <= 0xff) {
      return $this->_object_PutBuffer(
                       join('', pack('C3', $type, (0x80 | 1), $length),
                          $value
                       )
                    );
   } elsif ($length <= 0xffff) {
      return $this->_object_PutBuffer(
                       join('', pack('CCn', $type, (0x80 | 2), $length),
                          $value
                       )
                    );
   }

   $this->_asn1_EncodeError("Unable to encode ASN.1 length");
}

sub _asn1_EncodeInteger
{
   my ($this, $integer) = @_;
   my ($size, $value) = (4, '');

   if (!defined($integer)) {
      return $this->_asn1_EncodeError("INTEGER value not defined");
   }

   if ($integer !~ /^\d+$/) {
      return $this->_asn1_EncodeError("Expected numeric INTEGER value");
   }

   # Remove occurances of nine consecutive ones or zeros from the
   # most significant end of the two's complement integer.

   while (((!($integer & 0xff800000)) || 
           (($integer & 0xff800000) == 0xff800000)) && ($size > 1)) {
      $size--;
      $integer <<= 8;
   }

   # Build the integer
   while ($size--) {
      $value .= pack('C', (($integer & 0xff000000) >> 24));
      $integer <<= 8;
   }

   # Encode ASN.1 header
   $this->_asn1_EncodeTypeLength(INTEGER, $value);
}

sub _asn1_EncodeUnsignedIntegerType
{
   my ($this, $type, $integer) = @_;
   my ($size, $value, $signed) = (4, '', 0);

   if (!defined($type)) { $type = INTEGER; }

   if (!defined($integer)) { 
      return $this->_asn1_EncodeError("%s value not defined", 
                       _asn1_itoa($type) 
                    );
   }

   if ($integer !~ /^\d+$/) {
      return $this->_asn1_EncodeError("Expected numeric %s value", 
                       _asn1_itoa($type)
                    );
   }

   # Check to see if the most significant bit is set, if it is we
   # need to prefix the encoding with a zero byte.

   if ((($integer & 0xff000000) >> 24) & 0x80) {
      $signed = 1;
      $size++;
   }

   # Remove occurances of nine consecutive zeros from the most
   # significant end of the two's complement integer.

   while ((!($integer & 0xff800000)) && ($size > 1)) {
      $size--;
      $integer <<= 8;
   }

   # Add a zero byte so the integer is decoded as a positive value
   if ($signed) {
      $value .= pack('x');
      $size--;
   }

   # Build the integer
   while ($size-- > 0) {
      $value .= pack('C', (($integer & 0xff000000) >> 24));
      $integer <<= 8;
   }

   # Encode ASN.1 header
   $this->_asn1_EncodeTypeLength($type, $value);
}

sub _asn1_EncodeOctetString
{
   my ($this, $string) = @_;

   if (!defined($string)) {
      return $this->_asn1_EncodeError("OCTET STRING value not defined");
   }

   # Encode ASN.1 header
   $this->_asn1_EncodeTypeLength(OCTET_STRING, $string);
}

sub _asn1_EncodeNull
{
   my ($this) = @_;

   # Encode ASN.1 header 
   $this->_asn1_EncodeTypeLength(NULL, '');
}

sub _asn1_EncodeObjectIdentifier
{
   my ($this, $oid) = @_;
   my ($value, $subid, $mask, $bits, $tmask, $tbits) = ('', 0, 0, 0, 0, 0);

   if (!defined($oid)) {
      return $this->_asn1_Error("OBJECT IDENTIFIER value not defined");
   }

   # Input is expected in dotted notation, so break it up into subids
   my @subids = split(/\./, $oid);

   # Just in case there was a leading dot passed
   if ($subids[0] eq '') { shift(@subids); }

   # The first two subidentifiers are encoded into the first identifier
   # using the the equation: subid = ((first * 40) + second).  We just
   # return an error if there are not at least two subidentifiers.

   if (scalar(@subids) < 2) { 
      return $this->_asn1_EncodeError("Invalid OBJECT IDENTIFIER length"); 
   }

   $value = 40 * shift(@subids);
   $value = pack('C', ($value + shift(@subids)));

   # Encode each value as seven bits with the most significant bit
   # indicating the end of a subidentifier.

   foreach $subid (@subids) {
      if (($subid < 0x7f) && ($subid >= 0)) {
         $value .= pack('C', $subid);
      } else {
         $mask = 0x7f;
         $bits = 0;
         # Determine the number of bits need to encode the subidentifier
         for ($tmask = 0x7f, $tbits = 0; 
              $tmask != 0x00; 
              $tmask <<= 7, $tbits += 7) {
            if ($subid & $tmask) {
               $mask = $tmask;
               $bits = $tbits;
            }
         }
         # Now encode it, using the number of bits from above
         for ( ; $mask != 0x7f; $mask >>= 7, $bits -= 7) {
            # Handle a mask that was truncated above because
            # the subidentifier was four bytes long.
            if ((($mask & 0xffffffff) == 0xffe00000) ||
                  ($mask == 0x1e00000)) {
               $mask = 0xfe00000;
            }
            $value .= pack('C', ((($subid & $mask) >> $bits) | 0x80));
         }
         $value .= pack('C', ($subid & $mask));
      }
   }

   # Encode the ASN.1 header
   $this->_asn1_EncodeTypeLength(OBJECT_IDENTIFIER, $value);
}

sub _asn1_EncodeSequence
{
   my ($this) = @_;

   $this->_asn1_EncodeTypeLength(SEQUENCE, $this->_object_GetBuffer);
}

sub _asn1_EncodeIpAddress
{
   my ($this, $address) = @_;

   if (!defined($address)) {
      return $this->_asn1_EncodeError("IpAddress not defined");
   }

   if ($address  !~ /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/) {
      return $this->_asn1_EncodeError("Expected IpAddress in dotted notation");
   } 

   $this->_asn1_EncodeTypeLength(IPADDRESS, 
             pack('C4', split(/\./, $address))
          );
}

sub _asn1_EncodeCounter
{
   my ($this, $counter) = @_;

   $this->_asn1_EncodeUnsignedIntegerType(COUNTER, $counter);
}

sub _asn1_EncodeGauge
{
   my ($this, $gauge) = @_;

   $this->_asn1_EncodeUnsignedIntegerType(GAUGE, $gauge);
}

sub _asn1_EncodeTimeTicks
{
   my ($this, $timeticks) = @_;

   $this->_asn1_EncodeUnsignedIntegerType(TIMETICKS, $timeticks);
}

sub _asn1_EncodeOpaque
{
   my ($this, $opaque) = @_;

   if (!defined($opaque)) {
      return $this->_asn1_EncodeError("Opaque value not defined");
   }

   $this->_asn1_EncodeTypeLength(OPAQUE, $opaque);
}

sub _asn1_EncodeGetRequest
{
   my ($this) = @_;

   $this->_asn1_EncodeTypeLength(GET_REQUEST, $this->_object_GetBuffer);
}

sub _asn1_EncodeGetNextRequest
{
   my ($this) = @_;

   $this->_asn1_EncodeTypeLength(GET_NEXT_REQUEST, $this->_object_GetBuffer);
}

sub _asn1_EncodeGetResponse
{
   my ($this) = @_;

   $this->_asn1_EncodeTypeLength(GET_RESPONSE, $this->_object_GetBuffer);
}

sub _asn1_EncodeSetRequest
{
   my ($this) = @_;

   $this->_asn1_EncodeTypeLength(SET_REQUEST, $this->_object_GetBuffer);
}

sub _asn1_EncodeTrap
{
   my ($this) = @_;

   $this->_asn1_EncodeTypeLength(TRAP, $this->_object_GetBuffer);
}

sub _asn1_EncodeError
{
   my ($this, @error) = @_;

   # Clear the buffer
   $this->_object_ClearBuffer;

   $this->_object_Error(@error);
}


###
## Abstract Syntax Notation One (ASN.1) decode methods
###

sub _asn1_Decode
{
   my ($this, $expected) = @_;
   my ($method) = (undef);

   my $decode = {
        INTEGER,            '_asn1_DecodeInteger',
        OCTET_STRING,       '_asn1_DecodeOctetString',
        NULL,               '_asn1_DecodeNull',
        OBJECT_IDENTIFIER,  '_asn1_DecodeObjectIdentifier',
        SEQUENCE,           '_asn1_DecodeSequence',
        IPADDRESS,          '_asn1_DecodeIpAddress',
        COUNTER,            '_asn1_DecodeCounter',
        GAUGE,              '_asn1_DecodeGauge',
        TIMETICKS,          '_asn1_DecodeTimeTicks',
        OPAQUE,             '_asn1_DecodeOpaque',
        GET_REQUEST,        '_asn1_DecodeGetRequest',
        GET_NEXT_REQUEST,   '_asn1_DecodeGetNextRequest',
        GET_RESPONSE,       '_asn1_DecodeGetResponse',
        SET_REQUEST,        '_asn1_DecodeSetRequest',
        TRAP,               '_asn1_DecodeTrap',
   };

   if (defined($this->{'error'})) { return $this->_asn1_DecodeError; }

   my $type = $this->_object_GetBuffer(1);

   if (defined($type)) {
      $type = unpack('C', $type);
      if (defined($method = $decode->{$type})) {
         if (defined($expected)) {
            if ($type != $expected) {
               return $this->_asn1_DecodeError(
                                "Expected %s, but found %s", 
                                   _asn1_itoa($expected), _asn1_itoa($type)
                             );
            }
         }
         return $this->$method();
      } else {
         return $this->_asn1_DecodeError("Unknown ASN.1 type [0x%02x]", $type);
      }
   }
 
   $this->_asn1_DecodeError;
}

sub _asn1_DecodeLength
{
   my ($this) = @_;
   my ($length, $byte_cnt) = (0, 0);
  
   if (defined($this->{'error'})) { return $this->_asn1_DecodeError; }

   if (!defined($length = $this->_object_GetBuffer(1))) {
      return $this->_asn1_DecodeError;
   } 
   $length = unpack('C', $length);
 
   if ($length & 0x80) {
      $byte_cnt = ($length & 0x7f);
      if ($byte_cnt == 0) {
         return $this->_asn1_DecodeError(
                          "Indefinite ASN.1 lengths not supported"
                       );  
      } elsif ($byte_cnt == 1) {
         if (!defined($length = $this->_object_GetBuffer(1))) {
            return $this->_asn1_DecodeError;
         }
         $length = unpack('C', $length); 
      } elsif ($byte_cnt == 2) {
         if (!defined($length = $this->_object_GetBuffer(2))) {
            return $this->_asn1_DecodeError;
         }
         $length = unpack('n', $length);
      } else {   
         return $this->_asn1_DecodeError(
                          "ASN.1 length too long (%d bytes)", $byte_cnt 
                       );
      }
   }
 
   $length;
}

sub _asn1_DecodeInteger
{
   my ($this) = @_;
   my ($length, $integer, $signed, $byte) = (undef, 0, 0, undef);

   if (!defined($length = $this->_asn1_DecodeLength)) {
      return $this->_asn1_DecodeError;
   }

   # Just return zero if the object length is zero
   if ($length < 1) { return sprintf("%d", 0); }

   if (!defined($byte = $this->_object_GetBuffer(1))) { 
      return $this->_asn1_DecodeError; 
   }
   $length--;

   # If the first bit is set, the integer is negative
   if (($byte = unpack('C', $byte)) & 0x80) {
      $integer = -1;
      $signed = 1; 
   }

   if (($length > 4) || (($length > 3) && ($byte != 0))) {
      return $this->_asn1_DecodeError(
                       "INTEGER length too long (%d bytes)", ($length + 1)
                    );
   }

   $integer = (($integer << 8) | $byte);

   while ($length--) {
      if (!defined($byte = $this->_object_GetBuffer(1))) {
         return $this->_asn1_DecodeError;
      }
      $integer = (($integer << 8) | unpack('C', $byte));
   }
 
   if ($signed) { 
      return sprintf("%d", $integer); 
   } else {
      $integer = abs($integer);
      return sprintf("%u", $integer);
   }
}

sub _asn1_DecodeOctetString
{
   my ($this) = @_;
   my ($length, $string) = (undef, undef);

   if (!defined($length = $this->_asn1_DecodeLength)) {
      return $this->_asn1_DecodeError;
   }

   if (defined($string = $this->_object_GetBuffer($length))) {
      if (($string =~ /[\x00-\x08\x0b\x0e-\x1f\x7f-\xff]/g) && 
            ($this->{'translate'})) {
         $this->_debug_Message("translating OCTET STRING to printable hex " .
                   "string\n"
                );
         return sprintf("0x%s", unpack('H*', $string));
      } else {
         return $string;
      }
   } else {
      return $this->_asn1_DecodeError;
   }
}

sub _asn1_DecodeNull
{
   my ($this) = @_;
   my ($length) = (undef);

   if (!defined($length = $this->_asn1_DecodeLength)) {
      return $this->_asn1_DecodeError;
   }

   if ($length != 0) {
      return $this->_asn1_DecodeError("NULL length not equal to zero");
   }

   if ($this->{'translate'}) {
      $this->_debug_Message("translating NULL to 'NULL' string\n");
      return 'NULL';
   } else {
      return '';
   }
}

sub _asn1_DecodeObjectIdentifier
{
   my ($this) = @_;
   my ($length, $subid_cnt, $subid, $byte) = (undef, 1, 0, undef);
   my (@oid);

   if (!defined($length = $this->_asn1_DecodeLength)) {
      return $this->_asn1_DecodeError;
   }

   if ($length < 1) { return sprintf("%d", 0); }

   while ($length > 0) {
      $subid = 0;
      do {
         if (!defined($byte = $this->_object_GetBuffer(1))) {
            return $this->_asn1_DecodeError;
         }   
         $byte = unpack('C', $byte);
         if ($subid >= 0xffffffff) {
            return $this->_asn1_DecodeError(
                             "OBJECT IDENTIFIER subidentifier too large"
                          );
         }
         $subid = (($subid << 7) + ($byte & 0x7f)); 
         $length--;
      } while ($byte & 0x80);
      $oid[$subid_cnt++] = $subid;
   }

   # The first two subidentifiers are encoded into the first identifier
   # using the the equation: subid = ((first * 40) + second).

   $subid  = $oid[1];
   $oid[1] = int($subid % 40);
   $oid[0] = int(($subid - $oid[1]) / 40);

   # Return the OID in dotted notation
   join('.', @oid);
}

sub _asn1_DecodeSequence
{
   my ($this) = @_;

   # Return the length, instead of the value
   $this->_asn1_DecodeLength;
}

sub _asn1_DecodeIpAddress
{
   my ($this) = @_;
   my ($length, $address) = (undef, undef);

   if (!defined($length = $this->_asn1_DecodeLength)) {
      return $this->_asn1_DecodeError;
   }

   if ($length != 4) {
      return $this->_asn1_DecodeError(
                       "Invalid IpAddress length (% byte%s)", $length,
                          ($length == 1 ? '' : 's')
                    );
   }

   if (defined($address = $this->_object_GetBuffer(4))) {
      return join('.', unpack('C4', $address));
   } else {
      return $this->_asn1_DecodeError;
   }
}

sub _asn1_DecodeCounter
{
   my ($this) = @_;

   $this->_asn1_DecodeInteger;
}

sub _asn1_DecodeGauge
{
   my ($this) = @_;

   $this->_asn1_DecodeInteger;
}

sub _asn1_DecodeTimeTicks
{
   my ($this) = @_;
   my ($ticks) = (undef);

   if (defined($ticks = $this->_asn1_DecodeInteger)) {
      if ($this->{'translate'}) {
         $this->_debug_Message("translating %u TimeTicks to time\n", $ticks);
         return _asn1_ticks_to_time($ticks);
      } else {
         return $ticks;
      }
   } else {
      return $this->_asn1_DecodeError;
   }
}

sub _asn1_DecodeOpaque
{
   my ($this) = @_;

   $this->_asn1_DecodeOctetString;
}

sub _asn1_DecodeGetRequest
{
   my ($this) = @_;

   # Return the length, instead of the value
   $this->_asn1_DecodeLength;
}

sub _asn1_DecodeGetNextRequest
{
   my ($this) = @_;

   # Return the length, instead of the value
   $this->_asn1_DecodeLength;
}

sub _asn1_DecodeGetResponse
{
   my ($this) = @_;

   # Return the length, instead of the value
   $this->_asn1_DecodeLength;
}

sub _asn1_DecodeSetRequest
{
   my ($this) = @_;

   # Return the length, instead of the value
   $this->_asn1_DecodeLength;
}

sub _asn1_DecodeTrap
{
   my ($this) = @_;

   # Return the length, instead of the value
   $this->_asn1_DecodeLength;
}

sub _asn1_DecodeError
{
   my ($this, @error) = @_;

   $this->_object_Error(@error);
}


###
## Abstract Syntax Notation One (ASN.1) utility functions 
###

sub _asn1_itoa 
{
   my ($type) = @_;

   my $types = {
	INTEGER,            'INTEGER', 
	OCTET_STRING,       'OCTET STRING', 
	NULL,               'NULL', 
	OBJECT_IDENTIFIER,  'OBJECT IDENTIFER', 
	SEQUENCE,           'SEQUENCE', 
	IPADDRESS,          'IpAddress', 
	COUNTER,            'Counter', 
	GAUGE,              'Gauge', 
	TIMETICKS,          'TimeTicks', 
	OPAQUE,             'Opaque', 
	GET_REQUEST,        'GetRequest-PDU', 
	GET_NEXT_REQUEST,   'GetNextRequest-PDU', 
	GET_RESPONSE,       'GetResponse-PDU', 
	SET_REQUEST,        'SetRequest-PDU', 
	TRAP,               'Trap-PDU',
   };

   if (!defined($type)) { return '??'; }

   if (defined($types->{$type})) {
      return $types->{$type};
   } else {
      return sprintf("?? [0x%02x]", $type);
   }
}

sub _asn1_oid_subtree 
{
   my ($oid_p, $oid_c) = @_;
   my ($parent, $child) = (undef, undef);

   # Compares the parent OID (oid_p) to the child OID (oid_c)
   # and returns true if the child is equal to or is a subtree 
   # of the parent OID.
    
   if (!defined($oid_p)) { return 0; }
   if (!defined($oid_c)) { return 0; }

   # Remove leading dots
   $oid_p =~ s/^\.//;
   $oid_c =~ s/^\.//;

   my @subid_p = split(/\./, $oid_p);
   my @subid_c = split(/\./, $oid_c);

   while (@subid_p) {
      if (!defined($parent = shift(@subid_p))) { return 1; }
      if (!defined($child  = shift(@subid_c))) { return 0; }
      if ($parent != $child) { return 0; }
   }

   1;
}

sub _asn1_ticks_to_time 
{
   my ($ticks) = @_;
   my ($days, $minutes, $hours, $seconds) = (0, 0, 0, 0);

   if (!defined($ticks)) { $ticks = 0; }

   $days = int($ticks / (24 * 60 * 60 * 100));
   $ticks %= (24 * 60 * 60 * 100);

   $hours = int($ticks / (60 * 60 * 100));
   $ticks %= (60 * 60 * 100);

   $minutes = int($ticks / (60 * 100));
   $ticks %= (60 * 100);

   $seconds = ($ticks / 100);

   if ($days != 0){
      return sprintf("%d day%s, %02d:%02d:%05.02f", $days,
                ($days == 1 ? '' : 's'), $hours, $minutes, $seconds);
   } elsif ($hours != 0) {
      return sprintf("%d hour%s, %02d:%05.02f", $hours,
                ($hours == 1 ? '' : 's'), $minutes, $seconds);
   } elsif ($minutes != 0) {
      return sprintf("%d minute%s, %05.02f", $minutes,
                ($minutes == 1 ? '' : 's'), $seconds);
   } else {
      return sprintf("%04.02f second%s", $seconds, ($seconds == 1 ? '' : 's'));
   }

}

###
## User Datagram Protocol (UDP) methods
###

sub _udp_SendMessage
{
   my ($this) = @_;
   my ($retries, $rout, $rin) = (0, '', '');

   # Make sure the socket is still open
   if (!defined($this->{'socket'})) {
      return $this->_udp_Error("Session is closed");
   }

   # Get the number of retries
   $retries = $this->{'retries'};

   # Send the message
   if (!defined($this->_udp_SendBuffer)) { return $this->_udp_Error; }

   # Setup a vector to indicate received data on the socket
   vec($rin, fileno($this->{'socket'}), 1) = 1;

   while ($retries > 0) {
      if (select($rout=$rin, undef, undef, $this->{'timeout'})) {
         return $this->_udp_RecvBuffer;
      } else {
         $retries--;
         $this->_debug_Message("request timed out\n");
         if (!defined($this->_udp_SendBuffer)) { return $this->_udp_Error; }
      }
   }

   # Exceeded the number of retries
   return $this->_udp_Error("No response from agent on remote host '%s'", 
                    $this->{'hostname'}
                 );
}

sub _udp_SendBuffer
{
   my ($this) = @_;
   my ($length, $host_port, $host_addr) = (0, undef, undef);

   # Make sure the socket is still open
   if (!defined($this->{'socket'})) {
      return $this->_udp_Error("Session is closed");
   }

   ($host_port, $host_addr) = sockaddr_in($this->{'sockaddr_in'});
   $this->_debug_Message("address %s, port %d\n", inet_ntoa($host_addr), 
             $host_port
          );
   $this->_debug_DumpBuffer;

   # Transmit the contents of the buffer
   if (!defined($length = send($this->{'socket'}, $this->{'buffer'}, 0,
                             $this->{'sockaddr_in'}))) {
      return $this->_udp_Error("send(): %s", $!);
   }

   # Return the number of bytes transmitted
   $length;
}

sub _udp_RecvBuffer
{
   my ($this) = @_;
   my ($sockaddr_in, $host_port, $host_addr) = (undef, undef, undef);

   # Make sure the socket is still open
   if (!defined($this->{'socket'})) {
      return $this->_udp_Error("Session is closed");
   }

   # Clear the contents of the buffer
   $this->_object_ClearBuffer;

   # Fill the buffer
   if (!defined($sockaddr_in = recv($this->{'socket'}, $this->{'buffer'},
                                  $this->{'mtu'}, 0))) {
      return $this->_udp_Error("recv(): %s", $!);
   }

   ($host_port, $host_addr) = sockaddr_in($sockaddr_in);

   # Make sure that the address that we received the data from
   # was the one that we sent the request to.  Just take the first
   # eight bytes of the sockaddr_in structure since Windows NT seems
   # fill the last eight with random data instead of all zeros.

   if (substr($sockaddr_in, 0, 8) ne substr($this->{'sockaddr_in'}, 0, 8)) {
      return $this->_udp_Error("Received unexpected datagram from '%s'",
                       inet_ntoa($host_addr)
                    );
   }

   $this->_debug_Message("address %s, port %d\n", inet_ntoa($host_addr),
             $host_port
          );
   $this->_debug_DumpBuffer;

   # Return the address structure
   $sockaddr_in;
}

sub _udp_Error
{
   my ($this, @error) = @_;

   $this->_object_Error(@error);
}


###
## Object specific methods
###

sub _object_PutBuffer
{
   my ($this, $prefix) = @_;

   # Do not do anything if there has already been an error
   if (defined($this->{'error'})) { return $this->_object_EncodeError; }

   # Make sure we do not exceed our MTU
   if (($this->_object_BufferLength + length($prefix)) > $this->{'mtu'}) {
      return $this->_object_EncodeError("PDU size exceeded MTU");
   }
 
   # Add the prefix to the current buffer
   if ((defined($prefix)) && ($prefix ne '')) {
      $this->{'buffer'} = join('', $prefix, $this->{'buffer'});
   } 

   # Return what was just added in case someone wants it
   $prefix;
}

sub _object_GetBuffer
{
   my ($this, $offset) = @_;
   my ($substr) = ('');

   # Do not do anything if there has already been an error
   if (defined($this->{'error'})) { return $this->_object_DecodeError; }
  
   # Either return the whole buffer or a sub-string from the 
   # beginning of the buffer and then set the buffer equal to
   # what is left in the buffer
 
   if (defined($offset)) {
      $offset = abs($offset);
      if ($offset > length($this->{'buffer'})) {
         return $this->_object_DecodeError("Unexpected end of buffer");
      } else {
         $substr = substr($this->{'buffer'}, 0, $offset);
         $this->{'buffer'} = substr($this->{'buffer'}, $offset);
      }
   } else {
      $substr = $this->{'buffer'}; 
      $this->_object_ClearBuffer;
   }

   $substr;
}

sub _object_ClearBuffer
{
   my ($this) = @_;
 
   $this->{'buffer'} = '';
}

sub _object_ClearVarBindList
{
   my ($this) = @_;

   $this->{'var_bind_list'} = undef;
}

sub _object_ClearError
{
   my ($this) = @_;

   $this->{'error_status'} = 0;
   $this->{'error'} = undef;
}

sub _object_BufferLength
{
   my ($this) = @_;

   length $this->{'buffer'};
}

sub _object_EncodeError
{
   my ($this, @error) = @_;

   # Clear the buffer
   $this->_object_ClearBuffer;

   $this->_object_Error(@error);
}

sub _object_DecodeError
{
   my ($this, @error) = @_;

   $this->_object_Error(@error);
}

sub _object_Error
{
   my ($this, $format, @message) = @_;

   if (!defined($this->{'error'})) {
      $this->{'error'} = sprintf $format, @message;
      if ($this->{'debug'}) {
         my @info_1 = caller(1);
         my @info_2 = caller(2);
         printf("debug: [%d] %s(): %s\n", $info_1[2], $info_2[3], 
            $this->{'error'}
         );
      }
   }

   undef;
}


###
## Debug methods
###

sub _debug_Message
{
   my ($this, @message) = @_;

   if (!($this->{'debug'})) { return 0; }

   my @info_0 = caller(0);
   my @info_1 = caller(1);
   my $format = sprintf("debug: [%d] %s(): ", $info_0[2], $info_1[3]);

   $format = join('', $format, shift(@message));

   printf $format, @message;

   1;
}

sub _debug_DumpBuffer
{
   my ($this) = @_;
   my ($length, $offset, $line, $hex) = (0, 0, '', '');

   if (!($this->{'debug'})) { return undef; }

   $length = length($this->{'buffer'});

   $this->_debug_Message("%d byte%s\n", $length, ($length == 1 ? '' : 's'));
  
   while ($length > 0) {
      if ($length >= 16) { 
         $line = substr($this->{'buffer'}, $offset, 16);
      } else {
         $line = substr($this->{'buffer'}, $offset, $length);
      }
      $hex  = unpack('H*', $line);
      $hex .= ' ' x (32 - length($hex));
      $hex  = sprintf("%s %s %s %s  " x 4, unpack('a2' x 16, $hex));
      $line =~ s/[\x00-\x1f\x7f-\xff]/./g;
      printf("[%03d]  %s %s\n", $offset, uc($hex), $line);
      $offset += 16;
      $length -= 16;
   }
   print("\n");
   
   $this->{'buffer'};
}

# ============================================================================
1; # [end Net::SNMP]

__DATA__

###
## POD formatted documentation for Perl module Net::SNMP.
##
## $Id: Net-SNMP.pod,v 1.1 1998/10/14 12:26:10 dtown Exp $
## $Source: /home/dtown/Projects/Net-SNMP/Net-SNMP.pod,v $
##
###

=head1 NAME

Net::SNMP - Simple Network Management Protocol version-1

=head1 SYNOPSIS

use Net::SNMP;

=head1 DESCRIPTION

The module Net::SNMP implements an object oriented interface to the Simple 
Network Management Protocol version-1.  The module allows a Perl application 
to retrieve or update information on a remote host using the SNMP protocol.
The module assumes a basic understanding of the Simple Network Management 
Protocol and related network management concepts.

=head1 METHODS

When named arguments are used with methods, two different styles are
supported.  All examples use the IO:: style:

   $object->method(Argument => $value);

However, the dashed-option style is also allowed:

   $object->method(-argument => $value);


=head2 session() - create a new Net::SNMP object

   ($session, $error) = Net::SNMP->session([Hostname  => $hostname,] 
                                           [Community => $community,] 
                                           [Port      => $port,]);

This is the constructor for Net::SNMP objects. In scalar context, a
reference to a new Net::SNMP object is returned if the creation of the object
is successful.  In list context, a reference to a new Net::SNMP object and an 
error message string is returned.  

If an error occurs, the object reference returns the undefined value.
The error string may be used when this method is used in list context to
determine the cause of the error.

All arguments are optional and will be given the following defaults in the 
absence of a corresponding named argument: 

=over  

=item *

The default value for the remote B<Hostname> is "localhost".  The hostname 
can either be a network hostname or the dotted IP address of the host. 

=item *

The default value for the SNMP B<Community> name is "public".

=item *

The default value for the destination UDP B<Port> number is 161.  This is 
the port on which hosts using default values expect to receive all SNMP 
messages except for traps.  Port number 162 is the default port used by hosts 
expecting to receive SNMP traps.

=back

=head2 close() - close the UDP socket and clear all buffers and errors 

   $session->close;

This method closes the UDP socket and clears the errors, hash pointers, and 
buffers associated with the object.

=head2 get_request() - send a SNMP get-request to the remote agent

   $response = $session->get_request(@oids);

This method performs a SNMP get-request query to gather data from the remote
agent on the host associated with the Net::SNMP object.  The method takes
a list of OBJECT IDENTIFIERs in dotted notation.  Each OBJECT IDENTIFER is
placed into a single SNMP GetRequest-PDU in the same order that it held in
the original list.

Upon success, a reference to a hash is returned which contains the results of
the query. The undefined value is returned when a failure has occurred.  The
C<error()> method can be used to determine the cause of the failure.

The returned reference points to a hash constructed from the VarBindList
contained in the SNMP GetResponse-PDU.  The hash is created using the
ObjectName and the ObjectSyntax pairs in the VarBindList.  The keys of the
hash consist of the OBJECT IDENTIFIERs in dotted notation corresponding to
each ObjectName in the list.  The value of each hash entry is set to be the
value of the associated ObjectSyntax.  The hash reference can also be 
retrieved using the C<var_bind_list()> method.

=head2 get_next_request() - send a SNMP get-next-request to the remote agent

   $response = $session->get_next_request(@oids);

This method performs a SNMP get-next-request query to gather data from the
remote agent on the host associated with the Net::SNMP object.  The method
takes a list of OBJECT IDENTIFIERs in dotted notation.  Each OBJECT IDENTIFER
is placed into a single SNMP GetNextRequest-PDU in the same order that it
held in the original list.

Upon success, a reference to a hash is returned which contains the results of
the query. The undefined value is returned when a failure has occurred.  The
C<error()> method can be used to determine the cause of the failure.

The returned reference points to a hash constructed from the VarBindList
contained in the SNMP GetResponse-PDU.  The hash is created using the
ObjectName and the ObjectSyntax pairs in the VarBindList.  The keys of the
hash consist of the OBJECT IDENTIFIERs in dotted notation corresponding to
each ObjectName in the list.  The value of each hash entry is set to be the
value of the associated ObjectSyntax.  The hash reference can also be 
retrieved using the C<var_bind_list()> method.

=head2 set_request() - send a SNMP set-request to the remote agent

   $response = $session->set_request($oid, $type, $value 
                                    [, $oid, $type, $value]);

This method is used to modify data on the remote agent that is associated
with the Net::SNMP object using a SNMP set-request.  The method takes a
list of values consisting of groups of an OBJECT IDENTIFIER, an object type, 
and the actual value to be set.  The OBJECT IDENTIFIERs in each trio are to
be in dotted notation.  The object type is a byte corresponding to the ASN.1
type of value that is to be set.  Each of the supported types have been
defined and are exported by the package by default (see L<"EXPORTS">).

Upon success, a reference to a hash is returned which contains the results of
the query. The undefined value is returned when a failure has occurred.  The
C<error()> method can be used to determine the cause of the failure.

The returned reference points to a hash constructed from the VarBindList
contained in the SNMP GetResponse-PDU.  The hash is created using the
ObjectName and the ObjectSyntax pairs in the VarBindList.  The keys of the
hash consist of the OBJECT IDENTIFIERs in dotted notation corresponding to
each ObjectName in the list.  The value of each hash entry is set to be the
value of the associated ObjectSyntax.  The hash reference can also be 
retrieved using the C<var_bind_list()> method.

=head2 trap() - send an SNMP trap to the remote manager

   $octets = $session->trap([Enterprise   => $oid,]
                            [AgentAddr    => $ipaddress,]
                            [GenericTrap  => $generic,]
                            [SpecificTrap => $specific,]
                            [TimeStamp    => $timeticks,]
                            [VarBindList  => \@var_bind,]);

This method sends an SNMP trap to the remote manager associated with the
Net::SNMP object.  All arguments are optional and will be given the following 
defaults in the absence of a corresponding named argument: 

=over 

=item *

The default value for the trap B<Enterprise> is "1.3.6.1.4.1", which 
corresponds to "iso.org.dod.internet.private.enterprises".  The enterprise 
value is expected to be an OBJECT IDENTIFER in dotted notation. 

=item *

The default value for the trap B<AgentAddr> is the local IP address from
the host on which the script is running.  The agent-addr is expected to
be an IpAddress in dotted notation.

=item *

The default value for the B<GenericTrap> type is 6 which corresponds to 
"enterpriseSpecific".  The generic-trap types are defined and can be exported
upon request (see L<"EXPORTS">).

=item *

The default value for the B<SpecificTrap> type is 0.  No pre-defined values
are available for specific-trap types.

=item *

The default value for the trap B<TimeStamp> is the "uptime" of the script.  The
"uptime" of the script is the number of hundredths of seconds that have elapsed
since the script started running.  The time-stamp is expected to be a TimeTicks
number in hundredths of seconds.

=item *

The default value for the trap B<VarBindList> is an empty array reference.
The variable-bindings are expected to be in an array format consisting of 
groups of an OBJECT IDENTIFIER, an object type, and the actual value of the 
object.  This is identical to the list expected by the C<set_request()> method.
The OBJECT IDENTIFIERs in each trio are to be in dotted notation.  The object 
type is a byte corresponding to the ASN.1 type for the value. Each of the 
supported types have been defined and are exported by default (see 
L<"EXPORTS">).

=back

Upon success, the number of bytes transmitted is returned.  The undefined value
is returned when a failure has occurred.  The C<error()> method can be used to 
determine the cause of the failure.  Since there are no acknowledgements for
Trap-PDUs, there is no way to determine if the remote host actually received 
the trap.

=head2 get_table() - retrieve a table from the remote agent

   $response = $session->get_table($oid);

This method performs repeated SNMP get-next-request queries to gather data 
from the remote agent on the host associated with the Net::SNMP object.
The method takes a single OBJECT IDENTIFIER.  This OBJECT IDENTIFIER is used
as the base object for the SNMP get-next-requests.  Repeated SNMP 
get-next-requests are issued until the OBJECT IDENTIFER in the response is no 
longer a subtree of the base OBJECT IDENTIFIER.

Upon success, a reference to a hash is returned which contains the results of
the query. The undefined value is returned when a failure has occurred.  The
C<error()> method can be used to determine the cause of the failure.

The returned reference points to a hash constructed from the VarBindList
contained in the SNMP GetResponse-PDU.  The hash is created using the
ObjectName and the ObjectSyntax pairs in the VarBindList.  The keys of the
hash consist of the OBJECT IDENTIFIERs in dotted notation corresponding to
each ObjectName in the list.  The value of each hash entry is set to be the
value of the associated ObjectSyntax.  The hash reference can also be 
retrieved using the C<var_bind_list()> method.

B<WARNING:> Results from this method can become very large if the base
OBJECT IDENTIFIER is close the root of the SNMP MIB tree.

=head2 error() - get the current error message from the object

   $error_message = $session->error;

This method returns a text string explaining the reason for the last error.
A null string is returned if no error has occurred.

=head2 error_status() - get the current SNMP error-status from the object

   $error_status = $session->error_status;

This method returns the numeric value of the error-status contained in the 
last SNMP GetResponse-PDU.

=head2 var_bind_list() - get the hash reference to the last SNMP response

   $response = $session->var_bind_list;

This method returns a reference to the hash returned from the query or set 
methods.  The undefined value is returned if this value is empty.

=head2 timeout() - set or get the current timeout period for the object 

   $seconds = $session->timeout([$seconds]);

This method returns the current value for the UDP timeout for the Net::SNMP
object.  This value is the number of seconds that the object will wait for a
response from the agent on the remote host.  The default timeout is 2.0
seconds.

If a parameter is specified, the timeout for the object is set to the provided
value if it falls within the range 1.0 to 60.0 seconds.  The undefined value
is returned upon an error and the C<error()> method may be used to determine
the cause.

=head2 retries() - set or get the current retry count for the object

   $count = $session->retries([$count]);

This method returns the current value for the number of times to retry
sending a SNMP message to the remote host.  The default number of retries
is 2.

If a parameter is specified, the number of retries for the object is set to
the provided value if it falls within the range 0 to 20. The undefined value
is returned upon an error and the C<error()> method may be used to determine 
the cause.

=head2 mtu() - set or get the current MTU for the object

   $octets = $session->mtu([$octets]);

This method returns the current value for the Maximum Transport Unit for the
Net::SNMP object.  This value is the largest value in octets for an SNMP
message that can be transmitted or received by the object.  The default
MTU is 484 octets.

If a parameter is specified, the Maximum Transport Unit is set to the provided
value if it falls within the range 30 to 65535 octets.  The undefined value
is returned upon an error and the C<error()> method may be used to determine
the cause.

=head2 translate() - toggle the translation flag for the object

   $flag = $session->translate;

When the object decodes the GetResponse-PDU that is returned in response to
a SNMP message, certain values are translated into a more "human readable"
form.  By default the following translations occur: 

=over 

=item *

OCTET STRINGs containing non-printable characters are converted into a 
hexadecimal representation prefixed with "0x".

=item *

TimeTicks integer values are converted to a time format.

=item *

NULL values return the string "NULL" instead of a null string.

=back

This method is used to enable or disable this translation on a per object
basis.  Each call to the method will reverse the current state of translation.
The new state of the translation flag is returned by the method.  A true
value indicates that translation will occur.  

=head2 debug() - toggle the debug flag for the object

   $flag = $session->debug;

This method is used to enable or disable debugging on a per object basis.  By
default, debugging is off.  Each call to the method will reverse the current 
state of the debug flag.  The new state of the translation flag is returned
by the method.  A true value indicates that debugging is enabled.

=head1 EXPORTS

=over

=item Default

INTEGER, OCTET_STRING, NULL, OBJECT_IDENTIFIER, IPADDRESS, COUNTER, GAUGE,
TIMETICKS, OPAQUE 

=item Exportable

INTEGER, OCTET_STRING, NULL, OBJECT_IDENTIFIER, IPADDRESS, COUNTER, GAUGE,
TIMETICKS, OPAQUE, COLD_START, WARM_START, LINK_DOWN, LINK_UP, 
AUTHENTICATION_FAILURE, EGP_NEIGHBOR_LOSS, ENTERPRISE_SPECIFIC

=item Tags

=over 

=item :asn1

INTEGER, OCTET_STRING, NULL, OBJECT_IDENTIFIER, IPADDRESS, COUNTER, GAUGE,
TIMETICKS, OPAQUE

=item :generictrap

COLD_START, WARM_START, LINK_DOWN, LINK_UP, AUTHENTICATION_FAILURE,
EGP_NEIGHBOR_LOSS, ENTERPRISE_SPECIFIC

=item :ALL

All of the above exportable items.

=back

=back

=head1 EXAMPLES

This example gets the system uptime from a remote host:


   #!/bin/env perl

   use Net::SNMP();

   $hostname  = shift;
   $community = shift || 'public';
   $port      = shift || 161;

   ($session, $error) = Net::SNMP->session(
                                      Hostname  => $hostname,
                                      Community => $community,
                                      Port      => $port
                                   );

   if (!defined($session)) {
      printf("ERROR: %s\n", $error);
      exit 1;
   }

   $sysUpTime = '1.3.6.1.2.1.1.3.0';

   if (!defined($response = $session->get_request($sysUpTime))) {
      printf("ERROR: %s\n", $session->error);
      $session->close;
      exit 1;
   }

   printf("Uptime for host '%s' is: %s\n", $hostname, 
      $response->{$sysUpTime}
   );

   $session->close;

   exit 0;

This example sets the system contact information to "Help Desk":

   #!/bin/env perl

   use Net::SNMP;

   $hostname  = shift;
   $community = shift || 'public';
   $port      = shift || 161;

   ($session, $error) = Net::SNMP->session(
                                      Hostname  => $hostname,
                                      Community => $community,
                                      Port      => $port
                                   );

   if (!defined($session)) {
      printf("ERROR: %s\n", $error);
      exit 1;
   }

   $sysContact = '1.3.6.1.2.1.1.4.0';
   $contact    = 'Help Desk';

   $response = $session->set_request($sysContact, OCTET_STRING, $contact);
 
   if (!defined($response)) { 
      printf("ERROR: %s\n", $session->error);
      $session->close;
      exit 1;
   }


   printf("System contact for host '%s' set to: %s\n", $hostname, 
      $response->{$sysContact}
   );

   $session->close;

   exit 0; 


=head1 AUTHOR

David M. Town <town+@pitt.edu>

=head1 ACKNOWLEDGMENTS

The original concept for this module was based on F<SNMP_Session.pm> written 
by Simon Leinen <simon@switch.ch>.

The Abstract Syntax Notation One (ASN.1) encode and decode methods were 
derived by example from the CMU SNMP package whose copyright follows: 
Copyright (c) 1988, 1989, 1991, 1992 by Carnegie Mellon University.  
All rights reserved. 

=head1 COPYRIGHT

Copyright (c) 1998 David M. Town.  All rights reserved.  This program is
free software; you may redistribute it and/or modify it under the same
terms as Perl itself.

